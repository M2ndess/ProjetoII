create function calcular_duracao() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Calcula a diferença em horas entre hora_inicio e hora_fim
    NEW.duracao := EXTRACT(EPOCH FROM (NEW.hora_fim - NEW.hora_inicio)) / 3600.0;

    RETURN NEW;
END;
$$;

alter function calcular_duracao() owner to postgres;

